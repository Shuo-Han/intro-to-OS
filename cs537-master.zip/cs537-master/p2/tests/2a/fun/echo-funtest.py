import sys

print ' '.join(sys.argv[1:])
