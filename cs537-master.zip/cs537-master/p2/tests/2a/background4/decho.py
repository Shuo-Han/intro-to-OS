
import time, sys

time.sleep(int(sys.argv[1]))
print sys.argv[2]
