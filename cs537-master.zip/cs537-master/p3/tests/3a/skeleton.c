int m_error;
int Mem_Init(int sizeOfRegion) { return 0; }
void *Mem_Alloc(int size, int style) { return 0; }
int Mem_Free(void *ptr) { return 0; }
void Mem_Dump() { }
