int getrandom(int);
