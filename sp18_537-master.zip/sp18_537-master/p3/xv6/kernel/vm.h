int sys_munprotect(void);
int sys_mprotect(void);
