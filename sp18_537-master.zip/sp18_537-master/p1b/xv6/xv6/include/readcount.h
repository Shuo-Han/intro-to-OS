extern uint readcount;
